/*
 * strsearch.h
 *
 * Copyright (c) Chris Putnam 1995-2005
 *
 * Source code released under the GPL
 *
 */

#ifndef STRSEARCH_H
#define STRSEARCH_H

char *strsearch (const char *haystack, const char *needle);

#endif

