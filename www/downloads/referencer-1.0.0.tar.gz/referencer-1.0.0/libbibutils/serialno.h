/*
 * serialno.h
 *
 * Copyright (c) Chris Putnam 2005
 *
 * Source code released under the GPL
 *
 */
#ifndef SERIALNO_H
#define SERIALNO_H
#include <stdio.h>
#include "fields.h"

extern void addsn( fields *info, char *buf, int level );

#endif
