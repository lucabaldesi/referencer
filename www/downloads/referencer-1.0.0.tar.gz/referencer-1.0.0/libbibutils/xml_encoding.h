/* xml_getencoding.h
 */
extern int xml_getencoding( newstr *s );
