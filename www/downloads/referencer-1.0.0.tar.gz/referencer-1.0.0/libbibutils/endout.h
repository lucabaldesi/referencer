/*
 * endout.h
 *
 * Copyright (c) Chris Putnam 2005
 */
#ifndef ENDOUT_H
#define ENDOUT_H

extern void endout_write( fields *info, FILE *fp, int format_opts, 
		unsigned long refnum );

#endif
